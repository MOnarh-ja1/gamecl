extends Node2D
## NEON SPRINT. All art and sounds are generated at runtime: no paid assets.

const W = 1280.0
const H = 720.0
const SKY = Color("0b102b")
const CYAN = Color("30f7ef")
const PINK = Color("ff57b7")
const GOLD = Color("ffd458")
const LIME = Color("9dff8b")
const WHITE = Color("f3f8ff")
const MUTED = Color("a3b3d4")
const PLAYER_Y = 616.0
const SAVE_FILE = "user://neon_sprint.cfg"

var rng := RandomNumberGenerator.new()
var state := "menu"
var lane := 1
var visual_lane := 1.0
var jump_time := 0.0
var slide_time := 0.0
var shield_time := 0.0
var magnet_time := 0.0
var invulnerable := 0.0
var elapsed := 0.0
var travel := 0.0
var speed := 0.34
var spawn_timer := 0.1
var particles: Array = []
var entities: Array = []
var city: Array = []
var best := 0
var wallet := 0
var earned := 0
var selected_skin := 0
var owned_skins := [true, false, false]
var score := 0
var muted := false
var shake := 0.0
var flashes := 0.0
var sounds := {}
var font: Font

func _ready() -> void:
	rng.randomize()
	font = ThemeDB.fallback_font
	make_city()
	load_save()
	make_sounds()
	set_process(true)

func make_city() -> void:
	var seeded := RandomNumberGenerator.new()
	seeded.seed = 70481
	for layer in range(2):
		for i in range(28):
			city.append({"x": i * 52 - 75 + seeded.randi_range(-18, 18), "w": seeded.randi_range(35, 78), "h": seeded.randi_range(80, 225) * (0.78 if layer == 0 else 1.2), "layer": layer, "lights": seeded.randi_range(1, 4)})

func make_sounds() -> void:
	for key in ["coin", "jump", "slide", "hit", "shield", "click"]:
		var tone := AudioStreamPlayer.new()
		add_child(tone)
		var f := 0.0
		match key:
			"coin": f = 870.0
			"jump": f = 460.0
			"slide": f = 250.0
			"hit": f = 125.0
			"shield": f = 630.0
			"click": f = 650.0
		tone.stream = create_wave(f, 0.12 if key != "hit" else 0.28, key == "hit")
		tone.volume_db = -13.0
		sounds[key] = tone

func create_wave(freq: float, duration: float, noisy: bool = false) -> AudioStreamWAV:
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = 22050
	wav.stereo = false
	var count := int(duration * 22050.0)
	var bytes := PackedByteArray()
	bytes.resize(count * 2)
	for n in range(count):
		var t := float(n) / 22050.0
		var envelope := pow(1.0 - t / duration, 1.8)
		var pitch := freq * (1.0 + 0.4 * t / duration)
		var wave := sin(t * TAU * pitch)
		if noisy:
			wave = wave * 0.58 + sin(t * TAU * pitch * 2.21) * 0.42
		var value := int(clampf(wave * envelope * 16000.0, -32767.0, 32767.0))
		bytes[n * 2] = value & 255
		bytes[n * 2 + 1] = (value >> 8) & 255
	wav.data = bytes
	return wav

func sound(name: String) -> void:
	if not muted and sounds.has(name):
		var audio: AudioStreamPlayer = sounds[name]
		audio.stop()
		audio.play()

func load_save() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_FILE) == OK:
		best = int(cfg.get_value("save", "best", 0))
		wallet = int(cfg.get_value("save", "wallet", 0))
		selected_skin = clampi(int(cfg.get_value("save", "skin", 0)), 0, 2)
		owned_skins = cfg.get_value("save", "owned", [true, false, false])
		if owned_skins.size() != 3:
			owned_skins = [true, false, false]
		if not owned_skins[selected_skin]:
			selected_skin = 0
		muted = bool(cfg.get_value("save", "muted", false))

func save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("save", "best", best)
	cfg.set_value("save", "wallet", wallet)
	cfg.set_value("save", "skin", selected_skin)
	cfg.set_value("save", "owned", owned_skins)
	cfg.set_value("save", "muted", muted)
	cfg.save(SAVE_FILE)

func start_run() -> void:
	state = "playing"
	lane = 1
	visual_lane = 1.0
	jump_time = 0.0
	slide_time = 0.0
	shield_time = 0.0
	magnet_time = 0.0
	invulnerable = 0.0
	elapsed = 0.0
	travel = 0.0
	speed = 0.34
	spawn_timer = 0.65
	entities.clear()
	particles.clear()
	score = 0
	earned = 0
	shake = 0.0
	flashes = 0.0
	sound("click")

func end_run() -> void:
	if state != "playing":
		return
	state = "over"
	shake = 13.0
	flashes = 1.0
	wallet += earned
	if score > best:
		best = score
	save_game()
	sound("hit")
	emit_particles(Vector2(lane_x(visual_lane, 1.0), PLAYER_Y - 25), PINK, 28)

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var key := event.keycode
		if key == KEY_M:
			muted = not muted
			save_game()
			return
		if key == KEY_ESCAPE or key == KEY_P:
			if state == "playing":
				state = "pause"
			elif state == "pause":
				state = "playing"
			return
		if state == "playing":
			if key in [KEY_A, KEY_LEFT]:
				shift_lane(-1)
			elif key in [KEY_D, KEY_RIGHT]:
				shift_lane(1)
			elif key in [KEY_W, KEY_UP, KEY_SPACE]:
				jump()
			elif key in [KEY_S, KEY_DOWN, KEY_CTRL]:
				slide()
		elif key in [KEY_ENTER, KEY_SPACE, KEY_R] and state in ["menu", "over"]:
			start_run()
		elif key in [KEY_ENTER, KEY_SPACE] and state == "pause":
			state = "playing"
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		var p := event.position
		if state == "menu":
			if Rect2(475, 455, 330, 62).has_point(p):
				start_run()
			elif Rect2(379, 564, 522, 62).has_point(p):
				cycle_skin()
		elif state == "over":
			if Rect2(475, 476, 330, 62).has_point(p):
				start_run()
			elif Rect2(475, 550, 330, 55).has_point(p):
				state = "menu"
		elif state == "pause":
			if Rect2(475, 450, 330, 60).has_point(p):
				state = "playing"
			elif Rect2(475, 526, 330, 56).has_point(p):
				state = "menu"
				save_game()
		elif state == "playing":
			if Rect2(1200, 18, 54, 50).has_point(p):
				state = "pause"

func cycle_skin() -> void:
	var nxt := (selected_skin + 1) % 3
	var price: int = [0, 60, 170][nxt]
	if owned_skins[nxt]:
		selected_skin = nxt
	elif wallet >= price:
		wallet -= price
		owned_skins[nxt] = true
		selected_skin = nxt
		play_purchase_particles()
	else:
		sound("hit")
		return
	save_game()
	sound("click")

func play_purchase_particles() -> void:
	emit_particles(Vector2(640, 575), GOLD, 12)

func shift_lane(dir: int) -> void:
	var next := clampi(lane + dir, 0, 2)
	if lane != next:
		lane = next
		sound("click")

func jump() -> void:
	if jump_time <= 0.0 and slide_time <= 0.0:
		jump_time = 0.83
		sound("jump")

func slide() -> void:
	if slide_time <= 0.0 and jump_time <= 0.0:
		slide_time = 0.84
		sound("slide")

func _process(delta: float) -> void:
	var dt := minf(delta, 0.05)
	if state == "playing":
		elapsed += dt
		travel += dt * speed
		speed = minf(0.57, 0.34 + elapsed * 0.003)
		visual_lane = lerpf(visual_lane, float(lane), minf(1.0, dt * 13.0))
		jump_time = maxf(0.0, jump_time - dt)
		slide_time = maxf(0.0, slide_time - dt)
		shield_time = maxf(0.0, shield_time - dt)
		magnet_time = maxf(0.0, magnet_time - dt)
		invulnerable = maxf(0.0, invulnerable - dt)
		score += int(dt * (130.0 + elapsed * 0.8))
		spawn_timer -= dt
		if spawn_timer <= 0.0:
			spawn_wave()
			spawn_timer = rng.randf_range(0.81, 1.20) * (0.84 if elapsed > 45.0 else 1.0)
		move_entities(dt)
	else:
		elapsed += dt * 0.12 if state == "menu" else 0.0
	for i in range(particles.size() - 1, -1, -1):
		var p: Dictionary = particles[i]
		p["pos"] += p["vel"] * dt
		p["vel"] *= maxf(0.0, 1.0 - dt * 1.5)
		p["life"] -= dt
		if p["life"] <= 0.0:
			particles.remove_at(i)
	shake = maxf(0.0, shake - dt * 35.0)
	flashes = maxf(0.0, flashes - dt * 2.7)
	queue_redraw()

func spawn_wave() -> void:
	var danger_lane := rng.randi_range(0, 2)
	var obstacle_types := ["block", "block", "bar", "laser"]
	var first_type: String = obstacle_types[rng.randi_range(0, obstacle_types.size() - 1)]
	entities.append({"kind": first_type, "lane": danger_lane, "z": -0.12, "done": false})
	var blocked := [danger_lane]
	if elapsed > 24.0 and rng.randf() < 0.31:
		var second := (danger_lane + rng.randi_range(1, 2)) % 3
		blocked.append(second)
		entities.append({"kind": obstacle_types[rng.randi_range(0, 2)], "lane": second, "z": -0.12, "done": false})
	var safe: Array = []
	for l in range(3):
		if not blocked.has(l):
			safe.append(l)
	var coin_lane: int = safe[rng.randi_range(0, safe.size() - 1)]
	for j in range(3):
		entities.append({"kind": "coin", "lane": coin_lane, "z": -0.5 - float(j) * 0.21, "done": false})
	if rng.randf() < 0.09:
		entities.append({"kind": "shield" if rng.randf() < 0.65 else "magnet", "lane": coin_lane, "z": -0.85, "done": false})

func move_entities(dt: float) -> void:
	for i in range(entities.size() - 1, -1, -1):
		var e: Dictionary = entities[i]
		e["z"] += speed * dt
		if e["z"] > 1.18:
			entities.remove_at(i)
			continue
		if not e["done"] and e["z"] > 0.88 and e["z"] < 1.05:
			var same_lane := int(e["lane"]) == lane and absf(visual_lane - float(lane)) < 0.43
			if e["kind"] == "coin":
				if same_lane or (magnet_time > 0.0 and absf(float(e["lane"]) - visual_lane) <= 1.2):
					collect(e)
			elif e["kind"] in ["shield", "magnet"]:
				if same_lane:
					collect(e)
			elif same_lane:
				var avoided := false
				if e["kind"] == "bar":
					avoided = slide_time > 0.0
				elif e["kind"] == "laser":
					avoided = jump_time > 0.17
				if shield_time > 0.0 or invulnerable > 0.0 or avoided:
					e["done"] = true
					if shield_time > 0.0 and not avoided:
						shield_time = 0.0
						invulnerable = 1.2
						sound("shield")
				else:
					end_run()
					return
			elif e["z"] > 1.015:
				e["done"] = true

func collect(e: Dictionary) -> void:
	e["done"] = true
	if e["kind"] == "coin":
		earned += 1
		score += 25
		sound("coin")
		emit_particles(Vector2(lane_x(float(e["lane"]), 0.91), project_y(0.91) - 43), GOLD, 6)
	elif e["kind"] == "shield":
		shield_time = 8.0
		sound("shield")
		emit_particles(Vector2(lane_x(float(e["lane"]), 0.91), project_y(0.91) - 43), CYAN, 12)
	else:
		magnet_time = 8.0
		sound("shield")
		emit_particles(Vector2(lane_x(float(e["lane"]), 0.91), project_y(0.91) - 43), PINK, 12)

func emit_particles(pos: Vector2, tint: Color, count: int) -> void:
	for j in range(count):
		particles.append({"pos": pos, "vel": Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(90.0, 295.0), "life": rng.randf_range(0.25, 0.75), "tint": tint, "r": rng.randf_range(2.0, 5.0)})

func lane_x(l: float, z: float) -> float:
	return W * 0.5 + (l - 1.0) * (77.0 + 226.0 * clampf(z, 0.0, 1.0))

func project_y(z: float) -> float:
	return 155.0 + 510.0 * pow(clampf(z, 0.0, 1.0), 1.5)

func _draw() -> void:
	var offset := Vector2(rng.randf_range(-shake, shake), rng.randf_range(-shake, shake)) if shake > 0.05 else Vector2.ZERO
	draw_set_transform(offset)
	draw_background()
	draw_road()
	for e in entities:
		if e["z"] >= -0.05 and e["z"] < 1.16 and not e["done"]:
			draw_entity(e)
	draw_player()
	draw_effects()
	draw_set_transform(Vector2.ZERO)
	if state == "playing":
		draw_hud()
	elif state == "menu":
		draw_menu()
	elif state == "pause":
		draw_hud()
		draw_pause()
	elif state == "over":
		draw_over()
	if flashes > 0.0:
		draw_rect(Rect2(0, 0, W, H), Color(PINK, flashes * 0.20))

func draw_background() -> void:
	for i in range(24):
		var t := float(i) / 24.0
		draw_rect(Rect2(0, i * 30.0, W, 30.0), Color("080d24").lerp(Color("25163f"), t * 0.8))
	# Bright moon, horizon glow and parallax skylines.
	for r in range(5, 0, -1):
		draw_circle(Vector2(995, 115), 63.0 + r * 13.0, Color(0.17, 0.75, 0.92, 0.017))
	draw_circle(Vector2(995, 115), 51.0, Color("adfffb"))
	draw_circle(Vector2(984, 104), 45.0, Color("d5fff9"))
	for b in city:
		var l: int = b["layer"]
		var shift := fmod(travel * (12.0 if l == 0 else 31.0), 52.0)
		var x: float = b["x"] - shift
		var height: float = b["h"]
		var yy := 300.0 - height
		var tint := Color("17244e") if l == 0 else Color("141a3c")
		draw_rect(Rect2(x, yy, b["w"], height), tint)
		if l == 1:
			for row in range(3):
				for col in range(2):
					if (col + row + b["lights"]) % 3 != 0:
						draw_rect(Rect2(x + 10 + col * 17, yy + 18 + row * 30, 6, 11), Color(0.17, 0.95, 0.97, 0.42))
	draw_rect(Rect2(0, 293, W, 19), Color("121c47"))
	draw_line(Vector2(0, 307), Vector2(W, 307), Color(CYAN, 0.15), 2.0)
	# Horizon bloom.
	for r in range(8, 0, -1):
		draw_circle(Vector2(640, 161), 22.0 + r * 19.0, Color(0.16, 0.92, 0.96, 0.013))

func draw_road() -> void:
	polygon([Vector2(0, H), Vector2(510, 155), Vector2(770, 155), Vector2(W, H)], Color("132047"))
	polygon([Vector2(72, H), Vector2(530, 155), Vector2(750, 155), Vector2(1208, H)], Color("192141"))
	polygon([Vector2(110, H), Vector2(535, 155), Vector2(745, 155), Vector2(1170, H)], Color("202544"))
	# Lane markings become brighter and wider in the foreground.
	for j in range(2):
		var offset_l := (float(j) - 0.5)
		for stripe in range(12):
			var z := fmod(float(stripe) / 12.0 + travel * 0.9, 1.0)
			var z2 := minf(1.0, z + 0.037 + z * 0.018)
			var x1 := W * 0.5 + offset_l * (155.0 + 455.0 * z)
			var x2 := W * 0.5 + offset_l * (155.0 + 455.0 * z2)
			draw_line(Vector2(x1, project_y(z)), Vector2(x2, project_y(z2)), Color(0.30, 1, 0.98, 0.45 + 0.45 * z), 1.0 + z * 5.0)
	for side in [-1.0, 1.0]:
		var near := W / 2.0 + side * 529.0
		var far := W / 2.0 + side * 108.0
		draw_line(Vector2(far, 155), Vector2(near, H), Color(PINK, 0.43), 8.0)
		draw_line(Vector2(far, 155), Vector2(near, H), CYAN, 2.5)
		for light in range(9):
			var z := fmod(float(light) / 9.0 + travel * 0.65, 1.0)
			var yy := project_y(z)
			var xx := W / 2.0 + side * (108.0 + 421.0 * z)
			draw_line(Vector2(xx, yy), Vector2(xx, yy - (15.0 + z * 54.0)), Color("455d8f"), 2.0 + z * 3.0)
			draw_circle(Vector2(xx, yy - (15.0 + z * 54.0)), 2.0 + z * 5.0, CYAN)
	# Moving foreground light streaks.
	for i in range(14):
		var z := fmod(float(i) * 0.079 + travel * 0.48, 1.0)
		var yy := project_y(z)
		var side := -1.0 if i % 2 == 0 else 1.0
		var xx := 640.0 + side * (175.0 + 580.0 * z)
		draw_line(Vector2(xx, yy), Vector2(xx + side * 32.0 * z, yy + 34.0 * z), Color(PINK, 0.10 + 0.25 * z), maxf(1.0, z * 3))

func polygon(points: Array, tint: Color) -> void:
	draw_colored_polygon(PackedVector2Array(points), tint)

func draw_entity(e: Dictionary) -> void:
	var z: float = maxf(0.0, e["z"])
	var x := lane_x(float(e["lane"]), z)
	var y := project_y(z)
	var scale := 0.23 + z * 1.0
	var kind: String = e["kind"]
	if kind == "coin":
		var bob := sin(elapsed * 9.0 + z * 18.0) * 7.0 * scale
		var center := Vector2(x, y - 42.0 * scale + bob)
		draw_circle(center, 24.0 * scale, Color(GOLD, 0.10))
		draw_circle(center, 16.0 * scale, Color("be7c21"))
		draw_circle(center, 13.0 * scale, GOLD)
		draw_arc(center, 9.0 * scale, 0, TAU, 22, Color("fff3b7"), maxf(1.0, 2.0 * scale))
		draw_line(center + Vector2(-5, -7) * scale, center + Vector2(5, -7) * scale, Color("fff3b7"), 2.0 * scale)
		return
	if kind in ["shield", "magnet"]:
		var center := Vector2(x, y - 47.0 * scale)
		var tint := CYAN if kind == "shield" else PINK
		draw_circle(center, 28 * scale, Color(tint, 0.13))
		draw_arc(center, 20 * scale, elapsed * 2.0, elapsed * 2.0 + TAU * 0.85, 25, tint, maxf(2.0, 4.0 * scale))
		text_center("S" if kind == "shield" else "M", center + Vector2(0, 8 * scale), maxi(12, int(28 * scale)), WHITE)
		return
	var width := 73.0 * scale
	var height := (94.0 if kind == "block" else 106.0) * scale
	var top := y - height
	if kind == "block":
		draw_rect(Rect2(x - width / 2.0, top, width, height), Color("ff518b"))
		draw_rect(Rect2(x - width / 2.0 + 8 * scale, top + 9 * scale, width - 16 * scale, height - 18 * scale), Color("5a1c53"))
		for j in range(3):
			draw_line(Vector2(x - width / 2.0 + 9 * scale, top + (30 + j * 18) * scale), Vector2(x + width / 2.0 - 9 * scale, top + (12 + j * 18) * scale), PINK, 3.0 * scale)
	elif kind == "bar":
		var leg := 15.0 * scale
		draw_rect(Rect2(x - width / 2.0, top, leg, height), Color("40b7c3"))
		draw_rect(Rect2(x + width / 2.0 - leg, top, leg, height), Color("40b7c3"))
		draw_rect(Rect2(x - width / 2.0, top, width, 30.0 * scale), CYAN)
		draw_rect(Rect2(x - width / 2.0 + 6 * scale, top + 5 * scale, width - 12 * scale, 18.0 * scale), Color("115576"))
	else:
		# Short, low laser barrier: jump to pass.
		draw_rect(Rect2(x - width / 2, y - 38 * scale, width, 38 * scale), Color("9a2d70"))
		draw_line(Vector2(x - width / 2, y - 35 * scale), Vector2(x + width / 2, y - 35 * scale), PINK, maxf(2, 6 * scale))
		draw_line(Vector2(x - width / 2, y - 8 * scale), Vector2(x + width / 2, y - 8 * scale), PINK, maxf(2, 4 * scale))

func draw_player() -> void:
	var x := lane_x(visual_lane, 1.0)
	var lift := 0.0
	if jump_time > 0.0:
		lift = sin(PI * (1.0 - jump_time / 0.83)) * 155.0
	var slide := slide_time > 0.0
	var body_color: Color = [CYAN, PINK, LIME][selected_skin]
	var foot := PLAYER_Y + 38.0 - lift
	var bounce := sin(elapsed * 17.0) * 4.0 if state == "playing" and jump_time <= 0.0 else 0.0
	foot += bounce
	# Shadow on the track.
	draw_ellipse(Vector2(x, PLAYER_Y + 32), Vector2(45 + lift * 0.13, 10 + lift * 0.01), Color(0.02, 0.04, 0.10, 0.68))
	if shield_time > 0.0:
		draw_circle(Vector2(x, foot - 49), 80, Color(CYAN, 0.07))
		draw_arc(Vector2(x, foot - 49), 71, elapsed * 2, elapsed * 2 + TAU * 0.94, 50, CYAN, 4.0)
	if magnet_time > 0.0:
		draw_arc(Vector2(x, foot - 45), 64, -elapsed * 3, -elapsed * 3 + TAU * 0.6, 42, PINK, 3.0)
	if invulnerable > 0.0 and int(elapsed * 12) % 2 == 0:
		return
	# Runner robot, with animated swinging limbs.
	var swing := sin(elapsed * 18) * (16.0 if state == "playing" else 5.0)
	if slide:
		draw_line(Vector2(x - 11, foot - 25), Vector2(x - 37, foot), body_color, 13)
		draw_line(Vector2(x + 7, foot - 25), Vector2(x + 30, foot), body_color, 13)
		draw_rect(Rect2(x - 36, foot - 62, 72, 39), Color("e1f6ff"))
		draw_rect(Rect2(x - 30, foot - 59, 60, 26), body_color)
		draw_circle(Vector2(x + 21, foot - 56), 20, Color("f0faff"))
		draw_rect(Rect2(x + 16, foot - 64, 19, 11), Color("18214f"))
	else:
		draw_line(Vector2(x - 13, foot - 54), Vector2(x - 19 + swing, foot - 8), Color("dbeeff"), 15)
		draw_line(Vector2(x + 13, foot - 54), Vector2(x + 19 - swing, foot - 8), Color("dbeeff"), 15)
		draw_line(Vector2(x - 26, foot - 100), Vector2(x - 33 - swing, foot - 67), body_color, 14)
		draw_line(Vector2(x + 26, foot - 100), Vector2(x + 33 + swing, foot - 67), body_color, 14)
		draw_rect(Rect2(x - 27, foot - 118, 54, 72), Color("e4f9ff"))
		draw_rect(Rect2(x - 21, foot - 112, 42, 59), body_color)
		draw_rect(Rect2(x - 11, foot - 98, 22, 25), Color("1b275a"))
		draw_circle(Vector2(x, foot - 139), 29, Color("e4f9ff"))
		draw_rect(Rect2(x - 23, foot - 148, 46, 19), Color("17234b"))
		draw_rect(Rect2(x - 18, foot - 144, 36, 10), body_color)
		draw_line(Vector2(x, foot - 167), Vector2(x, foot - 176), body_color, 3.0)
		draw_circle(Vector2(x, foot - 179), 4, GOLD)

func draw_ellipse(center: Vector2, radii: Vector2, tint: Color) -> void:
	var pts := PackedVector2Array()
	for i in range(25):
		var a := TAU * float(i) / 24.0
		pts.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(pts, tint)

func draw_effects() -> void:
	for p in particles:
		var a := clampf(p["life"] * 2.0, 0.0, 1.0)
		draw_circle(p["pos"], p["r"] * a, Color(p["tint"], a))

func draw_hud() -> void:
	box(Rect2(22, 18, 258, 86), Color("101a40"), Color(CYAN, 0.45))
	text_at("СЧЁТ", Vector2(42, 49), 18, MUTED)
	text_at(str(score), Vector2(40, 88), 34, WHITE)
	box(Rect2(297, 18, 225, 86), Color("101a40"), Color(GOLD, 0.50))
	text_at("МОНЕТЫ", Vector2(318, 49), 18, MUTED)
	text_at("◆ " + str(earned), Vector2(316, 87), 30, GOLD)
	box(Rect2(538, 18, 206, 86), Color("101a40"), Color(PINK, 0.50))
	text_at("РЕКОРД", Vector2(560, 49), 18, MUTED)
	text_at(str(best), Vector2(558, 87), 30, WHITE)
	if shield_time > 0.0:
		box(Rect2(762, 18, 190, 48), Color("12314e"), CYAN)
		text_at("ЩИТ " + str(ceili(shield_time)) + "с", Vector2(783, 49), 20, CYAN)
	if magnet_time > 0.0:
		box(Rect2(762, 73, 190, 42), Color("472143"), PINK)
		text_at("МАГНИТ " + str(ceili(magnet_time)) + "с", Vector2(780, 102), 19, PINK)
	box(Rect2(1200, 18, 54, 50), Color("18254d"), CYAN)
	text_center("Ⅱ", Vector2(1227, 54), 32, WHITE)
	box(Rect2(352, 672, 577, 36), Color(0.06, 0.10, 0.24, 0.68), Color(0.38, 0.48, 0.70, 0.30))
	text_center("← A  СМЕНА ПОЛОСЫ  D →     ПРОБЕЛ  ПРЫЖОК     S  ПОДКАТ", Vector2(641, 698), 16, MUTED)

func draw_menu() -> void:
	draw_rect(Rect2(0, 0, W, H), Color(0.04, 0.05, 0.14, 0.45))
	box(Rect2(326, 85, 628, 574), Color(0.055, 0.075, 0.19, 0.94), Color(CYAN, 0.35))
	text_center("N E O N", Vector2(640, 197), 75, CYAN)
	text_center("S P R I N T", Vector2(640, 274), 73, WHITE)
	text_center("БЕСКОНЕЧНЫЙ ЗАБЕГ В ГОРОДЕ БУДУЩЕГО", Vector2(640, 322), 17, MUTED)
	draw_line(Vector2(448, 346), Vector2(832, 346), Color(PINK, 0.7), 3)
	text_center("УКЛОНЯЙСЯ  •  СОБИРАЙ  •  УСКОРЯЙСЯ", Vector2(640, 388), 20, GOLD)
	text_center("РЕКОРД  " + str(best) + "       ◆  " + str(wallet), Vector2(640, 427), 22, WHITE)
	button(Rect2(475, 455, 330, 62), "▶   ИГРАТЬ", CYAN)
	var next := (selected_skin + 1) % 3
	var skin_names := ["КИБЕР", "НЕОН", "ПЛАЗМА"]
	var cost: int = [0, 60, 170][next]
	var skin_caption := "СКИН: " + skin_names[selected_skin] + "    →    " + skin_names[next]
	if not owned_skins[next]:
		skin_caption += "  ◆" + str(cost)
	button(Rect2(379, 564, 522, 62), skin_caption, PINK)
	text_center("A / D — ВЛЕВО / ВПРАВО      W — ПРЫЖОК      S — ПОДКАТ", Vector2(640, 689), 17, MUTED)

func draw_over() -> void:
	draw_rect(Rect2(0, 0, W, H), Color(0.04, 0.04, 0.13, 0.72))
	box(Rect2(343, 120, 594, 525), Color("101736"), Color(PINK, 0.65))
	text_center("ЗАБЕГ ОКОНЧЕН", Vector2(640, 219), 45, PINK)
	text_center("ТВОЙ СЧЁТ", Vector2(640, 290), 22, MUTED)
	text_center(str(score), Vector2(640, 353), 64, WHITE)
	text_center("◆ +" + str(earned) + " МОНЕТ     ★ РЕКОРД " + str(best), Vector2(640, 410), 23, GOLD)
	button(Rect2(475, 476, 330, 62), "↻   ЕЩЁ РАЗ", CYAN)
	button(Rect2(475, 550, 330, 55), "ГЛАВНОЕ МЕНЮ", PINK)

func draw_pause() -> void:
	draw_rect(Rect2(0, 0, W, H), Color(0.035, 0.04, 0.13, 0.78))
	box(Rect2(346, 165, 588, 453), Color("101737"), Color(CYAN, 0.65))
	text_center("ПАУЗА", Vector2(640, 271), 58, CYAN)
	text_center("ESC / P — ПРОДОЛЖИТЬ", Vector2(640, 361), 22, MUTED)
	button(Rect2(475, 450, 330, 60), "▶   ПРОДОЛЖИТЬ", CYAN)
	button(Rect2(475, 526, 330, 56), "ГЛАВНОЕ МЕНЮ", PINK)

func box(rect: Rect2, fill: Color, outline: Color) -> void:
	draw_rect(rect, fill)
	draw_rect(rect, outline, false, 2.0)

func button(rect: Rect2, caption: String, tint: Color) -> void:
	draw_rect(rect, Color(tint, 0.13))
	draw_rect(rect, tint, false, 2.5)
	text_center(caption, Vector2(rect.position.x + rect.size.x / 2, rect.position.y + rect.size.y / 2 + 10), 25 if rect.size.x <= 340 else 21, WHITE)

func text_center(value: String, pos: Vector2, size: int, color: Color) -> void:
	var text_width := font.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	draw_string(font, Vector2(pos.x - text_width / 2.0, pos.y), value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func text_at(value: String, pos: Vector2, size: int, color: Color) -> void:
	draw_string(font, pos, value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)
