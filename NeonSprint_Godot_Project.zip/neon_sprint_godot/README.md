# NEON SPRINT 🚀

A self-contained, original **Godot 4.7.2** endless runner for Windows. Neon city art, runner robot, UI and sound effects are generated in GDScript at runtime — no external assets, accounts or plugins.

## Gameplay

- 3 lanes, endlessly spawning obstacle waves, increasing speed
- Obstacles: **pink blocks** (change lanes), **blue overhead gates** (slide), **low pink lasers** (jump)
- Coins, temporary shield and coin magnet
- Score, local record and coin wallet (saved between sessions)
- 3 unlockable skins, keyboard + mouse menus, restart, pause and mute

## Controls

| Key | Action |
| --- | --- |
| `A` / `←` | Switch left |
| `D` / `→` | Switch right |
| `W` / `↑` / `Space` | Jump over a low pink laser |
| `S` / `↓` / `Ctrl` | Slide under a blue overhead gate |
| `Esc` / `P` | Pause / resume |
| `R` / `Enter` | Restart from game-over screen |
| `M` | Toggle sound |

## Run from source

1. Download [Godot for Windows (standard version)](https://godotengine.org/download/windows/).
2. Unzip the project. In Godot, **Import** and select `project.godot`.
3. Press **F5** / **Run Project**.

## Build a Windows `.exe`

1. Install the **4.7.2 export templates** in Godot via **Editor → Manage Export Templates** (the editor version must match).
2. Choose **Project → Export → Windows Desktop → Export Project**.
3. Save as `NeonSprint.exe`. `embed_pck=true` means the game data is embedded in the executable.

Command-line method (after export templates are installed):

```bash
godot --headless --path . --editor --import --quit
godot --headless --path . --export-release "Windows Desktop" build/NeonSprint.exe
```

The GitHub Actions workflow at the repository root also builds the `.exe`, uploads a downloadable artifact and publishes the executable as a GitHub release.

### Technical details

- Godot 4.7.2, GDScript, 1280×720 resizable window, Compatibility renderer
- Procedurally drawn original graphics and generated in-memory WAV effects
- Saved settings are written locally to `user://neon_sprint.cfg`
- No internet access is required to play
